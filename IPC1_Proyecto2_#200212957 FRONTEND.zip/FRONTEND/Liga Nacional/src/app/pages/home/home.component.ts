import { Component, OnInit } from '@angular/core';

@Component
({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  constructor() { }

  equipo_temporal = [
    {
      code: "MAR",
      logo: "https://media.api-sports.io/football/teams/3643.png",
      name: "Marquense",
      venue_city: "San Marcos",
      founded: "1958",
      team_id: "3643"
      
    },
    {
      code: "SUC",
      logo: "https://media.api-sports.io/football/teams/3653.png",
      name: "Suchitepequez",
      team_id: "3653"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3656.png",
      name: "Antigua GFC",
      team_id: "3656"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3657.png",
      name: "Cobán Imperial",
      team_id: "3657"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3658.png",
      name: "Comunicaciones",
      team_id: "3658"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3660.png",
      name: "Deportivo Petapa",
      team_id: "3660"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3661.png",
      name: "Deportivo Sanarate",
      team_id: "3661"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3662.png",
      name: "Guastatoya",
      team_id: "3662"
    },
    {
      code: "MAL",
      logo: "https://media.api-sports.io/football/teams/3664.png",
      name: "Malacateco",
      team_id: "3664"
    },
    {
      code: "MUN",
      logo: "https://media.api-sports.io/football/teams/3665.png",
      name: "Municipal",
      team_id: "3665"
    },
    {
      code: "null",
      logo: "https://media.api-sports.io/football/teams/3666.png",
      name: "Siquinalá",
      team_id: "3666"
    },
    {
      code: "XEL",
      logo: "https://media.api-sports.io/football/teams/3667.png",
      name: "Xelaju",
      team_id: "3667"
    },
  ]

  ngOnInit(): void {
  }

}
